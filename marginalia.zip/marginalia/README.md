# Marginalia

A pixel-art, literary-themed Life RPG productivity tracker. Complete real-world
tasks ("Chapters") to earn "Ink" (XP), fill a growing bookshelf, and level up
your "Volume" — with a streak tracker ("Marginalia"), per-Discipline stats,
a Wax Seal economy, and a cosmetics shop ("The Bindery").

## Tech stack

- React 18 + Vite
- Firebase Authentication (email/password + Google)
- Firestore (real-time database)
- Tailwind CSS
- Framer Motion
- React Router
- Context API for state (no Redux/Zustand)

## Project structure

```
src/
  components/   PixelButton, ChapterCard, ChapterForm, InkMeter, StreakTracker,
                CharacterProfileCard, QuickStatsBlock, LoadingSkeleton,
                LevelUpModal, AchievementPopup, XPGainPopup, NavBar
  context/      AuthContext, CharacterContext
  firebase/     config.js, auth.js, firestore.js
  hooks/        useAuth, useCharacter, useChapters
  pages/        Login, Register, ForgotPassword, Dashboard, Bindery, Profile
  utils/        xpCurve.js, streakLogic.js, achievements.js
firestore.rules
```

## Setup

1. **Install dependencies**

   ```bash
   npm install
   ```

2. **Create a Firebase project**

   - Go to the [Firebase console](https://console.firebase.google.com/), create a project.
   - Enable **Authentication** → Email/Password and Google sign-in providers.
   - Enable **Firestore** (start in production mode).
   - In Project Settings → General, add a Web App and copy the config values.

3. **Configure environment variables**

   ```bash
   cp .env.example .env
   ```

   Fill in the six `VITE_FIREBASE_*` values from your Firebase web app config.

4. **Deploy Firestore rules**

   Using the Firebase CLI:

   ```bash
   firebase deploy --only firestore:rules
   ```

   Or paste the contents of `firestore.rules` into the Firestore console's Rules tab.

5. **Run locally**

   ```bash
   npm run dev
   ```

6. **Build & deploy** (Vercel/Netlify)

   ```bash
   npm run build
   ```

   Deploy the `dist/` folder, and set the same `VITE_FIREBASE_*` env vars in
   your hosting provider's dashboard. Vercel: `vercel --prod`. Netlify: drag
   `dist/` into the dashboard or use `netlify deploy --prod`.

## How the RPG systems work

- **Leveling (`utils/xpCurve.js`)**: `inkRequired(volume) = floor(100 * volume^1.5)`,
  a pure function so the curve is easy to retune later.
- **Atomic completion (`firebase/firestore.js: completeChapter`)**: runs inside
  a single Firestore transaction. The Ink award is read from the Chapter
  document itself (never trusted from the client at call time), so Ink/Volume
  can't desync and a completion can't be replayed for extra Ink.
- **Streaks (`utils/streakLogic.js`)**: pure day-key comparison — same day is a
  no-op, a one-day gap extends the streak, anything larger resets it to 1.
- **Achievements (`utils/achievements.js`)**: a fixed list of `{ id, name,
  flavor, check(user) }` entries, evaluated inside the same transaction right
  after a completion.
- **Custom Disciplines**: stored as free-text strings on the Chapter document
  (not a fixed enum), so a user-typed Discipline name aggregates and displays
  the same way as the five presets.

## Known limitations / next hardening steps

- Firestore rules restrict all reads/writes to the owning `uid`, but a
  determined client could still call the SDK directly and write arbitrary
  values onto their own `users/{uid}` doc. The app's own UI never does this —
  every stat change goes through `completeChapter`'s transaction — but for a
  production deployment, move that award logic into a callable Cloud Function
  and drop client write access to the stat fields in `firestore.rules`. That
  Cloud Function isn't included here.
- Pixel-art sprite assets (desk states, bookshelf segments, icons) are
  currently emoji placeholders (🕯️📖🏅) so the app runs with zero binary
  assets. Swap them for real sprite sheets in `src/assets/` and reference them
  from the components listed in the asset appendix of the original brief.
- The `shopItems` catalog in `Bindery.jsx` is defined client-side for
  simplicity; move it to the read-only `shopItems` Firestore collection when
  you want to edit the catalog without a redeploy.

## Deliverable checklist

- [x] Firestore Security Rules (`firestore.rules`)
- [x] `.env.example` for Firebase config keys
- [x] No `localStorage`/`sessionStorage` used — Firestore is the source of
      truth for all character/chapter/inventory state; a page refresh
      re-subscribes via `onSnapshot` and restores state.
- [x] Inline validation on Chapter creation/edit (no empty titles)
- [x] Optimistic UI on Chapter completion (see `ChapterCard.jsx`), rolling
      back with an in-theme error message on failure
- [ ] Public GitHub repo + live deployed URL — push this project to GitHub
      and deploy per the steps above; both depend on your own accounts.
