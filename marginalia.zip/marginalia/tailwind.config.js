/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        parchment: '#F4E9D8',
        'parchment-dark': '#E8D5B7',
        ink: '#2C3E50',
        burgundy: '#6B2737',
        gold: '#D4A574',
        'gold-bright': '#E8C088',
      },
      fontFamily: {
        pixel: ['"Press Start 2P"', 'monospace'],
        serif: ['"IM Fell English SC"', '"IM Fell English"', 'serif'],
      },
      boxShadow: {
        pixel: '4px 4px 0 0 rgba(44,62,80,0.9)',
        'pixel-sm': '2px 2px 0 0 rgba(44,62,80,0.9)',
      },
      keyframes: {
        flicker: {
          '0%,100%': { opacity: 1 },
          '50%': { opacity: 0.75 },
        },
        floatUp: {
          '0%': { transform: 'translateY(0)', opacity: 1 },
          '100%': { transform: 'translateY(-40px)', opacity: 0 },
        },
      },
      animation: {
        flicker: 'flicker 1.6s ease-in-out infinite',
        floatUp: 'floatUp 1.1s ease-out forwards',
      },
    },
  },
  plugins: [],
}
