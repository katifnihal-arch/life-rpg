import { useCharacter } from '../context/CharacterContext.jsx'

export function useChapters() {
  const { chapters, createChapter, updateChapter, deleteChapter, completeChapter } = useCharacter()
  const active = chapters.filter((c) => c.status === 'active')
  const completed = chapters.filter((c) => c.status === 'completed')
  return { chapters, active, completed, createChapter, updateChapter, deleteChapter, completeChapter }
}
