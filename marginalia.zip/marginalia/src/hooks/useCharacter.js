import { useCharacter as useCharacterContext } from '../context/CharacterContext.jsx'

export function useCharacter() {
  const { character, lastEvent, clearEvent } = useCharacterContext()
  return { character, lastEvent, clearEvent }
}
