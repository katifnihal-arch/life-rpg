import { motion } from 'framer-motion'

const DOODLES = ['✎', '❦', '☙', '✒', '❧', '✦', '☘']

export default function StreakTracker({ streakCount }) {
  const shown = Math.min(streakCount, 14)
  const candleState = streakCount >= 14 ? 3 : streakCount >= 7 ? 2 : streakCount >= 3 ? 1 : 0
  const candleGlow = ['opacity-40', 'opacity-60', 'opacity-85', 'opacity-100']

  return (
    <div>
      <div className="flex items-center gap-2 font-pixel text-[10px] text-ink mb-2">
        <span className={`inline-block ${candleGlow[candleState]} animate-flicker`} aria-hidden="true">
          🕯️
        </span>
        <span>MARGINALIA STREAK — {streakCount} day{streakCount === 1 ? '' : 's'}</span>
      </div>
      <div className="flex flex-wrap gap-1" role="img" aria-label={`${streakCount} day streak`}>
        {Array.from({ length: shown }).map((_, i) => (
          <motion.span
            key={i}
            initial={{ opacity: 0, scale: 0.6 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.03 }}
            className="text-burgundy text-sm"
          >
            {DOODLES[i % DOODLES.length]}
          </motion.span>
        ))}
        {streakCount > 14 && (
          <span className="font-pixel text-[10px] text-ink self-center ml-1">+{streakCount - 14}</span>
        )}
      </div>
    </div>
  )
}
