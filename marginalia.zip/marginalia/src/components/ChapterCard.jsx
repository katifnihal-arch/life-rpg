import { useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import PixelButton from './PixelButton.jsx'
import XPGainPopup from './XPGainPopup.jsx'

const DISCIPLINE_COLORS = {
  study: 'bg-[#7A8B6F]',
  fitness: 'bg-[#B0704B]',
  health: 'bg-[#7A9AA6]',
  work: 'bg-[#6B2737]',
  reading: 'bg-[#D4A574]',
  custom: 'bg-ink',
}

export default function ChapterCard({ chapter, onComplete, onEdit, onDelete }) {
  const reduceMotion = useReducedMotion()
  const [completing, setCompleting] = useState(false)
  const [confirmingDelete, setConfirmingDelete] = useState(false)
  const [showGain, setShowGain] = useState(false)
  const [error, setError] = useState(null)

  const isCompleted = chapter.status === 'completed'

  async function handleComplete() {
    setError(null)
    setCompleting(true)
    setShowGain(true) // optimistic: fire immediately, roll back on failure
    try {
      await onComplete(chapter.id)
    } catch (e) {
      setShowGain(false)
      setError('Your quill slipped — try again.')
    } finally {
      setCompleting(false)
    }
  }

  async function handleDelete() {
    try {
      await onDelete(chapter.id)
    } catch (e) {
      setError('Could not tear this page out — try again.')
      setConfirmingDelete(false)
    }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: reduceMotion ? 0 : 40, transition: { duration: 0.3 } }}
      whileHover={reduceMotion ? {} : { y: -2 }}
      className={`border-2 border-ink bg-parchment shadow-pixel-sm p-4 flex items-start gap-3 ${
        isCompleted ? 'opacity-60' : ''
      }`}
    >
      <span
        className={`w-3 h-3 mt-1 shrink-0 ${DISCIPLINE_COLORS[chapter.discipline] || DISCIPLINE_COLORS.custom}`}
        aria-hidden="true"
      />
      <div className="flex-1 min-w-0">
        <p className={`font-serif text-base text-ink ${isCompleted ? 'line-through' : ''}`}>
          {chapter.title}
        </p>
        {chapter.notes && <p className="text-xs text-ink/60 mt-1">{chapter.notes}</p>}
        <div className="flex items-center gap-2 mt-2 font-pixel text-[9px] text-ink/70">
          <span className="capitalize">{chapter.discipline}</span>
          {chapter.dueDate && <span>· due {chapter.dueDate}</span>}
          <span>· {chapter.inkReward} Ink</span>
        </div>
        {error && <p className="text-xs text-burgundy mt-2">{error}</p>}
      </div>

      {!isCompleted && (
        <div className="flex flex-col items-end gap-2 shrink-0">
          <div className="flex items-center gap-2">
            {showGain && <XPGainPopup amount={chapter.inkReward} />}
            <PixelButton
              variant="gold"
              disabled={completing}
              onClick={handleComplete}
              aria-label={`Complete chapter: ${chapter.title}`}
            >
              {completing ? '…' : 'Complete'}
            </PixelButton>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onEdit(chapter)}
              className="font-pixel text-[9px] text-ink underline"
            >
              Edit
            </button>
            {confirmingDelete ? (
              <span className="font-pixel text-[9px] text-burgundy flex items-center gap-1">
                Tear this page out?
                <button onClick={handleDelete} className="underline">Yes</button>
                <button onClick={() => setConfirmingDelete(false)} className="underline">No</button>
              </span>
            ) : (
              <button
                onClick={() => setConfirmingDelete(true)}
                className="font-pixel text-[9px] text-ink/60 underline"
              >
                Delete
              </button>
            )}
          </div>
        </div>
      )}
    </motion.div>
  )
}
