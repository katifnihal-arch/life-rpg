import { NavLink } from 'react-router-dom'
import { motion } from 'framer-motion'
import { logOut } from '../firebase/auth.js'

const links = [
  { to: '/', label: 'Desk' },
  { to: '/bindery', label: 'The Bindery' },
  { to: '/profile', label: 'Profile' },
]

export default function NavBar() {
  return (
    <nav className="border-b-2 border-ink bg-parchment px-4 py-3 flex items-center justify-between">
      <span className="font-serif text-lg">Marginalia</span>
      <div className="flex items-center gap-4">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.to === '/'}>
            {({ isActive }) => (
              <motion.span
                whileHover={{ y: -1 }}
                className={`font-pixel text-[10px] ${isActive ? 'text-burgundy' : 'text-ink'}`}
              >
                {l.label}
              </motion.span>
            )}
          </NavLink>
        ))}
        <button onClick={() => logOut()} className="font-pixel text-[10px] text-ink/60 underline">
          Sign out
        </button>
      </div>
    </nav>
  )
}
