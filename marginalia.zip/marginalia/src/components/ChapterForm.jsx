import { useState } from 'react'
import { motion } from 'framer-motion'
import PixelButton from './PixelButton.jsx'

const PRESET_DISCIPLINES = ['study', 'fitness', 'health', 'work', 'reading']

export default function ChapterForm({ initial, onSubmit, onCancel }) {
  const [title, setTitle] = useState(initial?.title || '')
  const [discipline, setDiscipline] = useState(initial?.discipline || 'study')
  const [customDiscipline, setCustomDiscipline] = useState(
    initial && !PRESET_DISCIPLINES.includes(initial.discipline) ? initial.discipline : '',
  )
  const [isCustom, setIsCustom] = useState(
    !!initial && !PRESET_DISCIPLINES.includes(initial.discipline),
  )
  const [notes, setNotes] = useState(initial?.notes || '')
  const [dueDate, setDueDate] = useState(initial?.dueDate || '')
  const [titleError, setTitleError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    const trimmed = title.trim()
    if (!trimmed) {
      setTitleError('Every Chapter needs a title.')
      return
    }
    setTitleError(null)
    setSubmitting(true)
    try {
      await onSubmit({
        title: trimmed,
        discipline: isCustom ? (customDiscipline.trim() || 'custom') : discipline,
        notes: notes.trim(),
        dueDate: dueDate || null,
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-labelledby="chapter-form-title"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-ink/50 flex items-center justify-center p-4 z-40"
      onClick={onCancel}
    >
      <motion.form
        initial={{ scale: 0.96, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        onClick={(e) => e.stopPropagation()}
        onSubmit={handleSubmit}
        className="bg-parchment border-2 border-ink shadow-pixel p-6 w-full max-w-md"
      >
        <h2 id="chapter-form-title" className="font-pixel text-sm text-ink mb-4">
          {initial ? 'Edit Chapter' : 'Open a New Chapter'}
        </h2>

        <label className="block mb-3">
          <span className="font-pixel text-[10px] text-ink">Title</span>
          <input
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
            aria-invalid={!!titleError}
            aria-describedby={titleError ? 'title-error' : undefined}
          />
          {titleError && (
            <span id="title-error" className="text-xs text-burgundy">{titleError}</span>
          )}
        </label>

        <label className="block mb-3">
          <span className="font-pixel text-[10px] text-ink">Discipline</span>
          <select
            value={isCustom ? 'custom' : discipline}
            onChange={(e) => {
              if (e.target.value === 'custom') setIsCustom(true)
              else {
                setIsCustom(false)
                setDiscipline(e.target.value)
              }
            }}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
          >
            {PRESET_DISCIPLINES.map((d) => (
              <option key={d} value={d}>{d[0].toUpperCase() + d.slice(1)}</option>
            ))}
            <option value="custom">Custom…</option>
          </select>
          {isCustom && (
            <input
              value={customDiscipline}
              onChange={(e) => setCustomDiscipline(e.target.value)}
              placeholder="Name your Discipline"
              className="mt-2 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
            />
          )}
        </label>

        <label className="block mb-3">
          <span className="font-pixel text-[10px] text-ink">Notes (optional)</span>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
          />
        </label>

        <label className="block mb-5">
          <span className="font-pixel text-[10px] text-ink">Due date (optional)</span>
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
          />
        </label>

        <div className="flex justify-end gap-3">
          <PixelButton type="button" variant="ghost" onClick={onCancel}>
            Cancel
          </PixelButton>
          <PixelButton type="submit" disabled={submitting}>
            {submitting ? 'Saving…' : initial ? 'Save Changes' : 'Open Chapter'}
          </PixelButton>
        </div>
      </motion.form>
    </motion.div>
  )
}
