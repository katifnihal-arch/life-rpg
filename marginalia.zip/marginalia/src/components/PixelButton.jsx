import { motion, useReducedMotion } from 'framer-motion'

const variants = {
  primary: 'bg-burgundy text-parchment',
  gold: 'bg-gold text-ink',
  ghost: 'bg-parchment text-ink border-2 border-ink',
  danger: 'bg-ink text-parchment',
}

export default function PixelButton({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  disabled = false,
  className = '',
  ...rest
}) {
  const reduceMotion = useReducedMotion()

  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      whileHover={reduceMotion || disabled ? {} : { y: -2, boxShadow: '4px 6px 0 0 rgba(44,62,80,0.9)' }}
      whileTap={reduceMotion || disabled ? {} : { y: 0, boxShadow: '1px 1px 0 0 rgba(44,62,80,0.9)' }}
      className={`font-pixel text-xs px-4 py-3 shadow-pixel-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${variants[variant]} ${className}`}
      {...rest}
    >
      {children}
    </motion.button>
  )
}
