import { AnimatePresence, motion } from 'framer-motion'

export default function InkMeter({ currentInk, inkToNextVolume, gainPopup }) {
  const pct = Math.min(100, Math.round((currentInk / inkToNextVolume) * 100))

  return (
    <div className="relative">
      <div className="flex justify-between font-pixel text-[10px] text-ink mb-1">
        <span>INK</span>
        <span>{currentInk} / {inkToNextVolume}</span>
      </div>
      <div className="h-4 w-full bg-parchment-dark border-2 border-ink relative overflow-hidden">
        <motion.div
          className="h-full bg-burgundy"
          initial={false}
          animate={{ width: `${pct}%` }}
          transition={{ type: 'spring', stiffness: 90, damping: 18 }}
        />
      </div>
      <AnimatePresence>
        {gainPopup && (
          <motion.span
            key={gainPopup.key}
            initial={{ opacity: 1, y: 0 }}
            animate={{ opacity: 0, y: -32 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.1, ease: 'easeOut' }}
            className="absolute right-0 -top-5 font-pixel text-[11px] text-burgundy"
          >
            +{gainPopup.amount} Ink
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  )
}
