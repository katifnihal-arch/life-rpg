import { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

export default function AchievementPopup({ achievement, onDismiss }) {
  useEffect(() => {
    if (!achievement) return
    const t = setTimeout(onDismiss, 4500)
    return () => clearTimeout(t)
  }, [achievement, onDismiss])

  return (
    <AnimatePresence>
      {achievement && (
        <motion.div
          role="status"
          aria-live="polite"
          initial={{ y: -80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -80, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-gold border-2 border-ink shadow-pixel px-5 py-3 flex items-center gap-3 cursor-pointer"
          onClick={onDismiss}
          onKeyDown={(e) => e.key === 'Enter' && onDismiss()}
          tabIndex={0}
        >
          <span className="text-xl" aria-hidden="true">🏅</span>
          <div>
            <p className="font-pixel text-[10px] text-ink">{achievement.name}</p>
            <p className="text-xs text-ink/70 font-serif">{achievement.flavor}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
