import { motion } from 'framer-motion'

// Standalone floating "+N Ink" — used where InkMeter's built-in popup
// slot isn't in scope (e.g. next to a ChapterCard's complete button).
export default function XPGainPopup({ amount }) {
  return (
    <motion.span
      initial={{ opacity: 1, y: 0, scale: 1 }}
      animate={{ opacity: 0, y: -28, scale: 1.1 }}
      transition={{ duration: 0.9, ease: 'easeOut' }}
      className="pointer-events-none font-pixel text-[10px] text-burgundy"
    >
      +{amount} Ink
    </motion.span>
  )
}
