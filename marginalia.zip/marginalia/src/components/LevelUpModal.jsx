import { motion, useReducedMotion, AnimatePresence } from 'framer-motion'
import { volumeLabel } from '../utils/xpCurve.js'
import PixelButton from './PixelButton.jsx'

export default function LevelUpModal({ volume, onDismiss }) {
  const reduceMotion = useReducedMotion()

  return (
    <AnimatePresence>
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label={`Reached ${volumeLabel(volume)}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-ink/80 flex items-center justify-center"
        onClick={onDismiss}
      >
        {!reduceMotion && (
          <motion.div
            initial={{ scale: 0, opacity: 1 }}
            animate={{ scale: 6, opacity: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="absolute w-24 h-24 rounded-full bg-burgundy"
            aria-hidden="true"
          />
        )}
        <motion.div
          initial={{ scale: 0.7, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 160, damping: 14 }}
          className="relative bg-parchment border-2 border-ink shadow-pixel p-8 text-center"
          onClick={(e) => e.stopPropagation()}
        >
          <p className="font-pixel text-[10px] text-ink/70 mb-2">A NEW BOOK JOINS THE SHELF</p>
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="font-serif text-4xl text-burgundy"
          >
            {volumeLabel(volume)}
          </motion.p>
          <div className="mt-6">
            <PixelButton onClick={onDismiss}>Continue Writing</PixelButton>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
