const DISCIPLINE_LABELS = {
  study: 'Study',
  fitness: 'Fitness',
  health: 'Health',
  work: 'Work',
  reading: 'Reading',
}

export default function QuickStatsBlock({ character }) {
  if (!character) return null
  const disciplines = character.disciplines || {}

  return (
    <div className="border-2 border-ink bg-parchment shadow-pixel-sm p-4">
      <h2 className="font-pixel text-[11px] text-ink mb-3">QUICK STATISTICS</h2>
      <dl className="grid grid-cols-2 gap-3 text-sm font-serif">
        <div>
          <dt className="text-ink/60 text-xs">Chapters completed</dt>
          <dd className="text-lg">{character.totalChaptersCompleted || 0}</dd>
        </div>
        <div>
          <dt className="text-ink/60 text-xs">Longest streak</dt>
          <dd className="text-lg">{character.longestStreak || 0} days</dd>
        </div>
      </dl>
      <div className="mt-4">
        <p className="text-ink/60 text-xs font-serif mb-2">By Discipline</p>
        <ul className="space-y-1">
          {Object.entries(disciplines).map(([key, value]) => (
            <li key={key} className="flex items-center gap-2">
              <span className="w-16 shrink-0 font-pixel text-[9px] text-ink">
                {DISCIPLINE_LABELS[key] || key}
              </span>
              <div className="flex-1 h-2 bg-parchment-dark border border-ink">
                <div
                  className="h-full bg-gold"
                  style={{ width: `${Math.min(100, value / 5)}%` }}
                />
              </div>
              <span className="font-pixel text-[9px] text-ink w-10 text-right">{value}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
