export default function LoadingSkeleton({ label = 'Turning the page…' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16" role="status" aria-live="polite">
      <span className="text-3xl animate-flicker" aria-hidden="true">🕯️</span>
      <p className="font-pixel text-[10px] text-ink">{label}</p>
    </div>
  )
}
