import { volumeLabel } from '../utils/xpCurve.js'
import InkMeter from './InkMeter.jsx'

export default function CharacterProfileCard({ character, gainPopup }) {
  if (!character) return null

  return (
    <div className="border-2 border-ink bg-parchment shadow-pixel p-5">
      <div className="flex items-start gap-4">
        <div
          className="w-16 h-16 shrink-0 bg-parchment-dark border-2 border-ink flex items-center justify-center text-2xl"
          aria-hidden="true"
        >
          📖
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-serif text-xl text-ink truncate">{character.displayName}</p>
          <p className="font-pixel text-[11px] text-burgundy mt-1">{volumeLabel(character.currentVolume)}</p>
          <div className="mt-3">
            <InkMeter
              currentInk={character.currentInk}
              inkToNextVolume={character.inkToNextVolume}
              gainPopup={gainPopup}
            />
          </div>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2 font-pixel text-[11px] text-ink">
        <span aria-hidden="true">🕯️</span>
        <span>{character.waxSeals} Wax Seals</span>
      </div>
    </div>
  )
}
