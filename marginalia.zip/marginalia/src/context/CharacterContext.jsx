import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { useAuth } from './AuthContext.jsx'
import {
  watchUserDoc,
  watchChapters,
  watchInventory,
  createChapter as createChapterDb,
  updateChapter as updateChapterDb,
  deleteChapter as deleteChapterDb,
  completeChapter as completeChapterDb,
  purchaseItem as purchaseItemDb,
} from '../firebase/firestore.js'

const CharacterContext = createContext(null)

export function CharacterProvider({ children }) {
  const { user } = useAuth()
  const [character, setCharacter] = useState(null)
  const [chapters, setChapters] = useState([])
  const [inventory, setInventory] = useState([])
  const [lastEvent, setLastEvent] = useState(null) // { type: 'levelUp'|'achievement'|'xp', payload }

  useEffect(() => {
    if (!user) {
      setCharacter(null)
      setChapters([])
      setInventory([])
      return
    }
    const unsubUser = watchUserDoc(user.uid, setCharacter)
    const unsubChapters = watchChapters(user.uid, setChapters)
    const unsubInventory = watchInventory(user.uid, setInventory)
    return () => {
      unsubUser()
      unsubChapters()
      unsubInventory()
    }
  }, [user])

  const createChapter = useCallback(
    (fields) => createChapterDb(user.uid, fields),
    [user],
  )

  const updateChapter = useCallback(
    (chapterId, fields) => updateChapterDb(user.uid, chapterId, fields),
    [user],
  )

  const deleteChapter = useCallback(
    (chapterId) => deleteChapterDb(user.uid, chapterId),
    [user],
  )

  const completeChapter = useCallback(
    async (chapterId) => {
      const result = await completeChapterDb(user.uid, chapterId)
      if (!result.alreadyCompleted) {
        setLastEvent({
          type: result.leveledUp ? 'levelUp' : 'xp',
          payload: result,
        })
        if (!result.leveledUp && result.newAchievements?.length === 0) {
          // plain xp gain, no modal to dismiss it: fade the popup on its own
          setTimeout(() => setLastEvent(null), 1300)
        }
        if (result.newAchievements?.length) {
          // queue achievement popups after the xp/level-up beat
          setTimeout(() => {
            setLastEvent({ type: 'achievement', payload: result.newAchievements[0] })
          }, result.leveledUp ? 1400 : 400)
        }
      }
      return result
    },
    [user],
  )

  const purchaseItem = useCallback(
    (item) => purchaseItemDb(user.uid, item),
    [user],
  )

  const clearEvent = useCallback(() => setLastEvent(null), [])

  return (
    <CharacterContext.Provider
      value={{
        character,
        chapters,
        inventory,
        lastEvent,
        clearEvent,
        createChapter,
        updateChapter,
        deleteChapter,
        completeChapter,
        purchaseItem,
      }}
    >
      {children}
    </CharacterContext.Provider>
  )
}

export function useCharacter() {
  const ctx = useContext(CharacterContext)
  if (!ctx) throw new Error('useCharacter must be used within CharacterProvider')
  return ctx
}
