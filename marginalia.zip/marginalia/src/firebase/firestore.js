import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  addDoc,
  deleteDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  runTransaction,
} from 'firebase/firestore'
import { db } from './config.js'
import { inkRequired } from '../utils/xpCurve.js'
import { applyStreakOnCompletion } from '../utils/streakLogic.js'
import { ACHIEVEMENTS } from '../utils/achievements.js'

const DEFAULT_DISCIPLINES = {
  study: 0,
  fitness: 0,
  health: 0,
  work: 0,
  reading: 0,
}

// --- User document -----------------------------------------------------

export async function ensureUserDocument(uid, { displayName, email }) {
  const ref = doc(db, 'users', uid)
  const snap = await getDoc(ref)
  if (snap.exists()) return
  await setDoc(ref, {
    displayName,
    email,
    currentVolume: 1,
    currentInk: 0,
    inkToNextVolume: inkRequired(1),
    waxSeals: 0,
    disciplines: DEFAULT_DISCIPLINES,
    streakCount: 0,
    lastActiveDate: null,
    totalChaptersCompleted: 0,
    longestStreak: 0,
    createdAt: serverTimestamp(),
  })
}

export function watchUserDoc(uid, callback) {
  return onSnapshot(doc(db, 'users', uid), (snap) => {
    callback(snap.exists() ? { id: snap.id, ...snap.data() } : null)
  })
}

// --- Chapters (tasks) ----------------------------------------------------

export function watchChapters(uid, callback) {
  const q = query(collection(db, 'users', uid, 'chapters'), orderBy('createdAt', 'desc'))
  return onSnapshot(q, (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  })
}

export async function createChapter(uid, { title, discipline, notes, dueDate, inkReward }) {
  if (!title || !title.trim()) throw new Error('A Chapter needs a title before it can be opened.')
  return addDoc(collection(db, 'users', uid, 'chapters'), {
    title: title.trim(),
    discipline: discipline || 'custom',
    notes: notes || '',
    dueDate: dueDate || null,
    inkReward: inkReward ?? 20,
    status: 'active',
    createdAt: serverTimestamp(),
    completedAt: null,
  })
}

export async function updateChapter(uid, chapterId, fields) {
  await updateDoc(doc(db, 'users', uid, 'chapters', chapterId), fields)
}

export async function deleteChapter(uid, chapterId) {
  await deleteDoc(doc(db, 'users', uid, 'chapters', chapterId))
}

// --- Completion: atomic XP/level/streak/discipline update ---------------
// Never trust a client-submitted Ink amount for the user total: re-derive
// the awarded amount from the chapter document itself, inside the same
// transaction that marks it complete, so a completion can't be replayed
// for extra Ink and Ink/Volume can never desync.

export async function completeChapter(uid, chapterId) {
  const userRef = doc(db, 'users', uid)
  const chapterRef = doc(db, 'users', uid, 'chapters', chapterId)

  const result = await runTransaction(db, async (tx) => {
    const [userSnap, chapterSnap] = await Promise.all([tx.get(userRef), tx.get(chapterRef)])
    if (!userSnap.exists()) throw new Error('Character sheet not found.')
    if (!chapterSnap.exists()) throw new Error('This Chapter no longer exists.')

    const chapter = chapterSnap.data()
    if (chapter.status === 'completed') {
      return { alreadyCompleted: true, user: userSnap.data(), newAchievements: [] }
    }

    const user = userSnap.data()
    const award = chapter.inkReward ?? 20
    const waxAward = Math.max(5, Math.round(award / 4))

    let currentInk = (user.currentInk || 0) + award
    let currentVolume = user.currentVolume || 1
    let inkToNextVolume = inkRequired(currentVolume)
    let leveledUp = false

    while (currentInk >= inkToNextVolume) {
      currentInk -= inkToNextVolume
      currentVolume += 1
      inkToNextVolume = inkRequired(currentVolume)
      leveledUp = true
    }

    const discipline = chapter.discipline || 'custom'
    const disciplines = { ...(user.disciplines || {}) }
    disciplines[discipline] = (disciplines[discipline] || 0) + award

    const { streakCount, longestStreak, lastActiveDate } = applyStreakOnCompletion(user)
    const totalChaptersCompleted = (user.totalChaptersCompleted || 0) + 1

    const updatedUser = {
      currentInk,
      currentVolume,
      inkToNextVolume,
      waxSeals: (user.waxSeals || 0) + waxAward,
      disciplines,
      streakCount,
      longestStreak,
      lastActiveDate,
      totalChaptersCompleted,
    }

    tx.update(userRef, updatedUser)
    tx.update(chapterRef, { status: 'completed', completedAt: serverTimestamp() })

    const mergedUser = { ...user, ...updatedUser, disciplines }
    const newAchievements = ACHIEVEMENTS.filter(
      (a) => !user.unlockedAchievements?.includes(a.id) && a.check(mergedUser),
    )
    if (newAchievements.length) {
      tx.update(userRef, {
        unlockedAchievements: [
          ...(user.unlockedAchievements || []),
          ...newAchievements.map((a) => a.id),
        ],
      })
    }

    return { alreadyCompleted: false, leveledUp, award, waxAward, user: mergedUser, newAchievements }
  })

  return result
}

// --- Inventory / Bindery --------------------------------------------------

export async function purchaseItem(uid, item) {
  const userRef = doc(db, 'users', uid)
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(userRef)
    const user = snap.data()
    if ((user.waxSeals || 0) < item.cost) {
      throw new Error('Not enough Wax Seals for that yet.')
    }
    tx.update(userRef, { waxSeals: user.waxSeals - item.cost })
    const invRef = doc(collection(db, 'users', uid, 'inventory'))
    tx.set(invRef, {
      itemName: item.name,
      type: item.type,
      acquiredAt: serverTimestamp(),
    })
  })
}

export function watchInventory(uid, callback) {
  return onSnapshot(collection(db, 'users', uid, 'inventory'), (snap) => {
    callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
  })
}
