import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth'
import { auth } from './config.js'
import { ensureUserDocument } from './firestore.js'

const googleProvider = new GoogleAuthProvider()

export function watchAuthState(callback) {
  return onAuthStateChanged(auth, callback)
}

export async function registerWithEmail(email, password, displayName) {
  const cred = await createUserWithEmailAndPassword(auth, email, password)
  await ensureUserDocument(cred.user.uid, {
    displayName: displayName || email.split('@')[0],
    email,
  })
  return cred.user
}

export async function loginWithEmail(email, password) {
  const cred = await signInWithEmailAndPassword(auth, email, password)
  return cred.user
}

export async function loginWithGoogle() {
  const cred = await signInWithPopup(auth, googleProvider)
  await ensureUserDocument(cred.user.uid, {
    displayName: cred.user.displayName || cred.user.email.split('@')[0],
    email: cred.user.email,
  })
  return cred.user
}

export async function requestPasswordReset(email) {
  await sendPasswordResetEmail(auth, email)
}

export async function logOut() {
  await signOut(auth)
}
