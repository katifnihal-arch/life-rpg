// Ink required to advance FROM the given Volume to the next one.
// Non-linear: gentle early climb, steepening later, without becoming
// grindy too soon.
export function inkRequired(volume) {
  return Math.floor(100 * Math.pow(volume, 1.5))
}

export function volumeLabel(volume) {
  const numerals = [
    '', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X',
    'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX',
  ]
  return `Vol. ${numerals[volume] || volume}`
}
