function toDayKey(date) {
  return date.toISOString().slice(0, 10) // YYYY-MM-DD, UTC-based day boundary
}

function daysBetween(aKey, bKey) {
  const a = new Date(aKey + 'T00:00:00Z')
  const b = new Date(bKey + 'T00:00:00Z')
  return Math.round((b - a) / 86400000)
}

// Given the user's current streak state, returns the updated streak fields
// after a Chapter completion "now". Same-day completions don't double-count;
// a completion exactly one day after the last one extends the streak;
// anything further resets it to 1.
export function applyStreakOnCompletion(user, now = new Date()) {
  const todayKey = toDayKey(now)
  const lastKey = user.lastActiveDate

  let streakCount = user.streakCount || 0

  if (!lastKey) {
    streakCount = 1
  } else {
    const gap = daysBetween(lastKey, todayKey)
    if (gap === 0) {
      // already active today, streak unchanged
    } else if (gap === 1) {
      streakCount += 1
    } else {
      streakCount = 1
    }
  }

  const longestStreak = Math.max(user.longestStreak || 0, streakCount)

  return { streakCount, longestStreak, lastActiveDate: todayKey }
}

// Called on app load (not on completion) to detect a missed day and reset
// the visible streak even before the next Chapter is completed.
export function currentStreakGivenInactivity(user, now = new Date()) {
  if (!user.lastActiveDate) return 0
  const gap = daysBetween(user.lastActiveDate, toDayKey(now))
  return gap > 1 ? 0 : user.streakCount || 0
}
