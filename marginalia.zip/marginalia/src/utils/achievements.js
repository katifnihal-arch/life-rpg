export const ACHIEVEMENTS = [
  {
    id: 'first-chapter',
    name: 'First Chapter Closed',
    flavor: 'Every volume starts with a single page.',
    check: (u) => (u.totalChaptersCompleted || 0) >= 1,
  },
  {
    id: 'streak-7',
    name: '7-Day Marginalia Streak',
    flavor: 'A week of doodles in the margin.',
    check: (u) => (u.streakCount || 0) >= 7,
  },
  {
    id: 'volume-5',
    name: 'Vol. V Reached',
    flavor: 'The shelf is starting to fill in.',
    check: (u) => (u.currentVolume || 1) >= 5,
  },
  {
    id: 'reading-master',
    name: 'Master of Reading',
    flavor: '20 Chapters closed under Reading.',
    check: (u) => (u.disciplines?.reading || 0) >= 20 * 20, // 20 chapters at ~20 Ink each, tuned loosely
  },
  {
    id: 'chapters-50',
    name: 'Fifty Chapters',
    flavor: 'A well-worn desk and a steady hand.',
    check: (u) => (u.totalChaptersCompleted || 0) >= 50,
  },
]
