import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import PixelButton from '../components/PixelButton.jsx'
import { loginWithEmail, loginWithGoogle } from '../firebase/auth.js'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await loginWithEmail(email, password)
      navigate('/')
    } catch (err) {
      setError('That email and password didn\u2019t open any desk. Try again.')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleGoogle() {
    setError(null)
    try {
      await loginWithGoogle()
      navigate('/')
    } catch (err) {
      setError('The Google sign-in was interrupted. Try again.')
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex items-center justify-center p-4"
    >
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-parchment border-2 border-ink shadow-pixel p-8"
      >
        <h1 className="font-serif text-2xl text-ink mb-1">Marginalia</h1>
        <p className="font-pixel text-[10px] text-ink/60 mb-6">Open your desk</p>

        <label className="block mb-3">
          <span className="font-pixel text-[10px]">Email</span>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
          />
        </label>
        <label className="block mb-2">
          <span className="font-pixel text-[10px]">Password</span>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
          />
        </label>
        <div className="text-right mb-4">
          <Link to="/forgot-password" className="font-pixel text-[9px] text-ink/60 underline">
            Forgot password?
          </Link>
        </div>

        {error && <p className="text-xs text-burgundy mb-4">{error}</p>}

        <PixelButton type="submit" disabled={submitting} className="w-full mb-3">
          {submitting ? 'Opening…' : 'Sign In'}
        </PixelButton>
        <PixelButton type="button" variant="ghost" onClick={handleGoogle} className="w-full">
          Continue with Google
        </PixelButton>

        <p className="mt-6 text-center font-pixel text-[9px] text-ink/60">
          New here?{' '}
          <Link to="/register" className="underline text-burgundy">
            Start a new Volume
          </Link>
        </p>
      </form>
    </motion.div>
  )
}
