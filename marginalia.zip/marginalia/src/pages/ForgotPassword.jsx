import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import PixelButton from '../components/PixelButton.jsx'
import { requestPasswordReset } from '../firebase/auth.js'

export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      await requestPasswordReset(email)
      setSent(true)
    } catch (err) {
      setError('Could not find a desk under that email.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex items-center justify-center p-4"
    >
      <div className="w-full max-w-sm bg-parchment border-2 border-ink shadow-pixel p-8">
        <h1 className="font-serif text-2xl text-ink mb-1">Forgotten Ink</h1>
        <p className="font-pixel text-[10px] text-ink/60 mb-6">We'll send a reset scroll</p>

        {sent ? (
          <p className="font-serif text-sm text-ink">
            A reset scroll has been sent to your inbox. Follow the link there to set a new password.
          </p>
        ) : (
          <form onSubmit={handleSubmit}>
            <label className="block mb-4">
              <span className="font-pixel text-[10px]">Email</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full border-2 border-ink bg-white/60 px-2 py-2 font-serif text-sm"
              />
            </label>
            {error && <p className="text-xs text-burgundy mb-4">{error}</p>}
            <PixelButton type="submit" disabled={submitting} className="w-full">
              {submitting ? 'Sending…' : 'Send Reset Scroll'}
            </PixelButton>
          </form>
        )}

        <p className="mt-6 text-center font-pixel text-[9px] text-ink/60">
          <Link to="/login" className="underline text-burgundy">
            Back to sign in
          </Link>
        </p>
      </div>
    </motion.div>
  )
}
