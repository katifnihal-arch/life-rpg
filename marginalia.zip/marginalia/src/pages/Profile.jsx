import { motion } from 'framer-motion'
import { useCharacter as useCharacterCtx } from '../context/CharacterContext.jsx'
import { volumeLabel } from '../utils/xpCurve.js'
import { ACHIEVEMENTS } from '../utils/achievements.js'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'

export default function Profile() {
  const { character, inventory } = useCharacterCtx()
  if (!character) return <LoadingSkeleton label="Fetching your profile…" />

  const unlocked = new Set(character.unlockedAchievements || [])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-3xl mx-auto p-4 md:p-8 space-y-8"
    >
      <div>
        <h1 className="font-serif text-2xl">{character.displayName}</h1>
        <p className="font-pixel text-[11px] text-burgundy mt-1">{volumeLabel(character.currentVolume)}</p>
      </div>

      <section>
        <h2 className="font-pixel text-[11px] mb-3">THE SHELF</h2>
        {inventory.length === 0 ? (
          <p className="font-serif text-sm text-ink/60">Nothing on the shelf yet — visit The Bindery.</p>
        ) : (
          <ul className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {inventory.map((item) => (
              <li key={item.id} className="border-2 border-ink bg-parchment shadow-pixel-sm p-3">
                <p className="font-serif text-sm">{item.itemName}</p>
                <p className="font-pixel text-[9px] text-ink/60 capitalize mt-1">{item.type}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="font-pixel text-[11px] mb-3">ACHIEVEMENTS</h2>
        <ul className="space-y-2">
          {ACHIEVEMENTS.map((a) => (
            <li
              key={a.id}
              className={`border-2 p-3 flex items-center gap-3 ${
                unlocked.has(a.id) ? 'border-ink bg-parchment' : 'border-ink/20 bg-parchment/40 opacity-60'
              }`}
            >
              <span aria-hidden="true">{unlocked.has(a.id) ? '🏅' : '🔒'}</span>
              <div>
                <p className="font-serif text-sm">{a.name}</p>
                <p className="font-pixel text-[9px] text-ink/60">{a.flavor}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </motion.div>
  )
}
