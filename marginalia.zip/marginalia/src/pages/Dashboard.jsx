import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useCharacter as useCharacterCtx } from '../context/CharacterContext.jsx'
import { useChapters } from '../hooks/useChapters.js'
import CharacterProfileCard from '../components/CharacterProfileCard.jsx'
import StreakTracker from '../components/StreakTracker.jsx'
import QuickStatsBlock from '../components/QuickStatsBlock.jsx'
import ChapterCard from '../components/ChapterCard.jsx'
import ChapterForm from '../components/ChapterForm.jsx'
import PixelButton from '../components/PixelButton.jsx'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'
import LevelUpModal from '../components/LevelUpModal.jsx'
import AchievementPopup from '../components/AchievementPopup.jsx'

export default function Dashboard() {
  const { character, lastEvent, clearEvent } = useCharacterCtx()
  const { active, createChapter, updateChapter, deleteChapter, completeChapter } = useChapters()
  const [formOpen, setFormOpen] = useState(false)
  const [editingChapter, setEditingChapter] = useState(null)
  const [toast, setToast] = useState(null)

  if (!character) return <LoadingSkeleton label="Setting the desk…" />

  async function handleCreate(fields) {
    try {
      await createChapter(fields)
      setFormOpen(false)
    } catch (e) {
      setToast(e.message || 'Your quill slipped — try again.')
    }
  }

  async function handleEditSubmit(fields) {
    try {
      await updateChapter(editingChapter.id, fields)
      setEditingChapter(null)
    } catch (e) {
      setToast('Could not save those changes — try again.')
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-4xl mx-auto p-4 md:p-8 grid md:grid-cols-3 gap-6"
    >
      <div className="md:col-span-1 space-y-6">
        <CharacterProfileCard
          character={character}
          gainPopup={
            lastEvent?.type === 'xp'
              ? { key: Date.now(), amount: lastEvent.payload.award }
              : null
          }
        />
        <div className="border-2 border-ink bg-parchment shadow-pixel-sm p-4">
          <StreakTracker streakCount={character.streakCount || 0} />
        </div>
        <QuickStatsBlock character={character} />
      </div>

      <div className="md:col-span-2">
        <div className="flex items-center justify-between mb-4">
          <h1 className="font-serif text-2xl">Open Chapters</h1>
          <PixelButton onClick={() => setFormOpen(true)}>+ New Chapter</PixelButton>
        </div>

        {toast && (
          <p className="text-xs text-burgundy mb-3" role="alert">
            {toast}
          </p>
        )}

        {active.length === 0 ? (
          <p className="font-serif text-ink/60 text-sm border-2 border-dashed border-ink/30 p-6 text-center">
            No open Chapters yet. Every Volume starts with a single page — add one above.
          </p>
        ) : (
          <ul className="space-y-3">
            <AnimatePresence>
              {active.map((chapter) => (
                <li key={chapter.id}>
                  <ChapterCard
                    chapter={chapter}
                    onComplete={completeChapter}
                    onEdit={setEditingChapter}
                    onDelete={deleteChapter}
                  />
                </li>
              ))}
            </AnimatePresence>
          </ul>
        )}
      </div>

      {formOpen && (
        <ChapterForm onSubmit={handleCreate} onCancel={() => setFormOpen(false)} />
      )}
      {editingChapter && (
        <ChapterForm
          initial={editingChapter}
          onSubmit={handleEditSubmit}
          onCancel={() => setEditingChapter(null)}
        />
      )}

      {lastEvent?.type === 'levelUp' && (
        <LevelUpModal volume={character.currentVolume} onDismiss={clearEvent} />
      )}
      <AchievementPopup
        achievement={lastEvent?.type === 'achievement' ? lastEvent.payload : null}
        onDismiss={clearEvent}
      />
    </motion.div>
  )
}
