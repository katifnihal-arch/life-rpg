import { useState } from 'react'
import { motion } from 'framer-motion'
import { useCharacter as useCharacterCtx } from '../context/CharacterContext.jsx'
import PixelButton from '../components/PixelButton.jsx'
import LoadingSkeleton from '../components/LoadingSkeleton.jsx'

// Static shop catalog. In production this mirrors the read-only
// shopItems/{itemId} collection in Firestore.
const SHOP_ITEMS = [
  { id: 'theme-midnight', name: 'Midnight Study Theme', type: 'theme', cost: 40, description: 'Swap the parchment for deep navy.' },
  { id: 'badge-early-bird', name: 'Early Bird Badge', type: 'badge', cost: 25, description: 'For Chapters closed before 8am.' },
  { id: 'decor-inkwell', name: 'Brass Inkwell', type: 'decoration', cost: 30, description: 'A decoration for your desk scene.' },
  { id: 'decor-plant', name: 'Potted Fern', type: 'decoration', cost: 20, description: 'A small patch of green for the shelf.' },
  { id: 'badge-night-owl', name: 'Night Owl Badge', type: 'badge', cost: 25, description: 'For Chapters closed after midnight.' },
  { id: 'theme-rose', name: 'Rose Parchment Theme', type: 'theme', cost: 40, description: 'A warmer, rosier palette.' },
]

export default function Bindery() {
  const { character, inventory, purchaseItem } = useCharacterCtx()
  const [message, setMessage] = useState(null)
  const owned = new Set(inventory.map((i) => i.itemName))

  if (!character) return <LoadingSkeleton label="Unlocking the Bindery…" />

  async function handleBuy(item) {
    setMessage(null)
    try {
      await purchaseItem(item)
      setMessage({ tone: 'good', text: `${item.name} added to The Shelf.` })
    } catch (e) {
      setMessage({ tone: 'bad', text: e.message || 'Not enough Wax Seals yet.' })
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-4xl mx-auto p-4 md:p-8"
    >
      <div className="flex items-center justify-between mb-2">
        <h1 className="font-serif text-2xl">The Bindery</h1>
        <span className="font-pixel text-[11px]">🕯️ {character.waxSeals} Wax Seals</span>
      </div>
      <p className="font-serif text-sm text-ink/60 mb-6">Spend Wax Seals on themes, badges, and desk decorations.</p>

      {message && (
        <p className={`text-xs mb-4 ${message.tone === 'bad' ? 'text-burgundy' : 'text-ink'}`} role="status">
          {message.text}
        </p>
      )}

      <div className="grid sm:grid-cols-2 gap-4">
        {SHOP_ITEMS.map((item) => {
          const isOwned = owned.has(item.name)
          return (
            <motion.div
              key={item.id}
              whileHover={{ y: -2 }}
              className="border-2 border-ink bg-parchment shadow-pixel-sm p-4 flex flex-col"
            >
              <p className="font-serif text-base">{item.name}</p>
              <p className="text-xs text-ink/60 mt-1 flex-1">{item.description}</p>
              <div className="flex items-center justify-between mt-3">
                <span className="font-pixel text-[10px]">{item.cost} 🕯️</span>
                <PixelButton
                  variant="gold"
                  disabled={isOwned || character.waxSeals < item.cost}
                  onClick={() => handleBuy(item)}
                >
                  {isOwned ? 'Owned' : 'Buy'}
                </PixelButton>
              </div>
            </motion.div>
          )
        })}
      </div>
    </motion.div>
  )
}
